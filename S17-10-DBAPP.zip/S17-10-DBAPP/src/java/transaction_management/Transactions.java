/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package transaction_management;

/**
 *
 * @author Anja
 */

import java.util.*;
import java.sql.*;

public class Transactions {
    private int transaction_ID;
    private Timestamp date_of_transaction;
    int customer_ID;
    
    private ArrayList<Integer> transaction_ID_list = new ArrayList<>();
    private ArrayList<Timestamp> date_of_transaction_list = new ArrayList<>();
    private ArrayList<Integer> customer_ID_list = new ArrayList<>();
    
    public int transaction_list() throws ClassNotFoundException
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
    
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT transaction_ID, date_of_transaction, customer_ID FROM Transactions", Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = pstmt.executeQuery();
            
            transaction_ID_list.clear();
            date_of_transaction_list.clear();
            customer_ID_list.clear();
            
            while(rs.next())
            {
                transaction_ID = rs.getInt("transaction_ID");
                date_of_transaction = rs.getTimestamp("date_of_transaction");
                customer_ID = rs.getInt("customer_ID");
                
                transaction_ID_list.add(transaction_ID);
                date_of_transaction_list.add(date_of_transaction);
                customer_ID_list.add(customer_ID);
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
    
    public int add_transaction() throws ClassNotFoundException
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
    
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Transactions(date_of_transaction, customer_ID) VALUE(?, ?)", Statement.RETURN_GENERATED_KEYS);
            pstmt.setTimestamp(1, date_of_transaction);
            pstmt.setInt(2, customer_ID);
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            
            if(rs.next())
                transaction_ID = rs.getInt(1);
            
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
    
    public ArrayList<Integer> get_transaction_ID_list()
    {
        return this.transaction_ID_list;
    }
    
    public ArrayList<Timestamp> get_date_of_transaction_list()
    {
        return this.date_of_transaction_list;
    }
    
    public ArrayList<Integer> get_customer_ID_list()
    {
        return this.customer_ID_list;
    }
    
    public int get_transaction_ID()
    {
        return this.transaction_ID;
    }
    
    public Timestamp get_date_of_transaction()
    {
        return this.date_of_transaction;
    }
    
    public int get_customer_ID()
    {
        return this.customer_ID;
    }
    
    public void set_date_of_transaction(Timestamp date_of_transaction)
    {
        this.date_of_transaction = date_of_transaction;
    }
    
    public void set_customer_ID(int customer_ID)
    {
        this.customer_ID = customer_ID;
    }
    
    
}
