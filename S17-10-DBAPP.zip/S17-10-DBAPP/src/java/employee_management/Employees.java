/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employee_management;

/**
 *
 * @author Anja
 */

import java.util.ArrayList;
import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Employees {
    
    private int employee_ID;
    private double weekly_salary;
    private Date hire_date;
    private int user_ID;
    private String role_ID;
    
    private ArrayList<Integer> employee_ID_list = new ArrayList<>();
    private ArrayList<Double> weekly_salary_list = new ArrayList<>();
    private ArrayList<Date> hire_date_list = new ArrayList<>();
    private ArrayList<Integer> user_ID_list = new ArrayList<>();
    private ArrayList<String> role_ID_list = new ArrayList<>();
    
    public int employee_list() throws ClassNotFoundException
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
    
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT employee_ID, weekly_salary, hire_date, user_ID, role_ID FROM Employees", Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = pstmt.executeQuery();
            
            employee_ID_list.clear();
            weekly_salary_list.clear();
            hire_date_list.clear();
            user_ID_list.clear();
            role_ID_list.clear();
            
            while(rs.next())
            {
                employee_ID = rs.getInt("employee_ID");
                weekly_salary = rs.getDouble("weekly_salary");
                hire_date = rs.getDate("hire_date");
                user_ID = rs.getInt("user_ID");
                role_ID = rs.getString("role_ID");
                
                employee_ID_list.add(employee_ID);
                weekly_salary_list.add(weekly_salary);
                hire_date_list.add(hire_date);
                user_ID_list.add(user_ID);
                role_ID_list.add(role_ID);
            }
            
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
    public int add_employee() throws ClassNotFoundException
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
    
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Employees(weekly_salary, hire_date, user_ID, role_ID) VALUE(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            pstmt.setDouble(1, weekly_salary);
            pstmt.setDate(2, hire_date);
            pstmt.setInt(3, user_ID);
            pstmt.setString(4, role_ID);

            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            
            if(rs.next())
                employee_ID = rs.getInt(1);
            
            rs.close();
            pstmt.close();
            conn.close();
            return 1;
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
            return 0;
        }
    }
    
    public ArrayList<Integer> get_employee_ID_list()
    {
        return this.employee_ID_list;
    }
    
    public ArrayList<Double> get_weekly_salary_list()
    {
        return this.weekly_salary_list;
    }
    
    public ArrayList<Date> get_hire_date_list()
    {
        return this.hire_date_list;
    }
    
    public ArrayList<Integer> get_user_ID_list()
    {
        return this.user_ID_list;
    }
    
    public ArrayList<String> get_role_ID_list()
    {
        return this.role_ID_list;
    }
    
    public double calculate_earnings(int employee_ID, Date hire_date) throws ClassNotFoundException
    {
        double earnings = 0.0;
        
        try
        {   
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            long weeks_worked = ChronoUnit.WEEKS.between(hire_date.toLocalDate(), LocalDate.now());
            PreparedStatement pstmt = conn.prepareStatement("SELECT weekly_salary * ? FROM Employees WHERE employee_ID = ?");
            pstmt.setLong(1, weeks_worked);
            pstmt.setInt(2, employee_ID);
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next())
                earnings = rs.getDouble(1);
            
            rs.close();
            pstmt.close();
            conn.close();
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
        }
        
        return earnings;
    }
    
    public String find_role(String role_ID) throws ClassNotFoundException
    {
        String name = "";
        
        try
        {   
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/s17_group10_concertdb", "root", "password");
            System.out.println("Connection successful.");
            
            PreparedStatement pstmt = conn.prepareStatement("SELECT role_name FROM Employee_Roles WHERE role_ID = ?");
            pstmt.setString(1, role_ID);
            
            ResultSet rs = pstmt.executeQuery();
            
            if(rs.next())
                name = rs.getString(1);
            
            rs.close();
            pstmt.close();
            conn.close();
        }
        catch (SQLException e)
        {
            System.out.println("Error: " + e.getMessage());
        }
        
        return name;
    }
}
